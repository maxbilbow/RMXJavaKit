package click.rmx.persistence.model;

/**
 * Created by bilbowm on 23/09/2015.
 */
public interface IEntity {
    Long getId();
    void setId(Long id);
}
