package click.rmx.persistence.model;

public class Bombs {
	public static Bomb newBomb() {
		return new Bomb();
	}
	
}
