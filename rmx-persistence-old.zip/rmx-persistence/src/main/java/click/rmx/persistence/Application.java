package click.rmx.persistence;

import click.rmx.persistence.model.Bomb;
import click.rmx.persistence.service.BombService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.Duration;
import java.time.Instant;

/**
 * Created by Max on 07/10/2015.
 */
@SpringBootApplication
@EnableAutoConfiguration
public class Application extends SpringApplication {

    @Autowired
    BombService bombService;


    public static void main(String[] args) {

        BombService bombService = new Application().bombService;
        Instant then = Instant.now();
        Instant now = Instant.now();
        while (true) {
            now = Instant.now();
            if (Duration.between(now,then).getSeconds() > 1) {
                System.out.println("Add bomb.");
                bombService.save(new Bomb());
                then = now;
            }
        }
    }

}
