package physics;

public enum PhysicsBodyType {
	Static, Dynamic, Kinematic, Transient
}
