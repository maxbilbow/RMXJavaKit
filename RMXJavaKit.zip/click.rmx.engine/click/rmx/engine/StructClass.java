public @interface StructClass {
	String hello() default "Hello";
}
