package behaviours;

public @interface Warning {

	String value();

}
