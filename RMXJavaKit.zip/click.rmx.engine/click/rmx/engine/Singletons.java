public class Singletons {

//	static bool _gameControllerInitialized = false;
//	public static boolean GameControllerInitialized() {
//			return _gameController != null;//_gameControllerInitialized;
//	}
	

//	static IGameController _gameController;
// 	public static IGameController GameController {
//		get{ 
//			return _gameController;
//		}
//	}
}