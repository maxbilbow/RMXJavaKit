public class Categories {
	public static final String GEOMETRY = "rmxCat:GeometryInterface";
}
