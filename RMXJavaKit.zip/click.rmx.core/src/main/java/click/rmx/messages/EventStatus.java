package messages;

public enum EventStatus {

	Active, Completed, Idle, Success, Failure, ForceNewEvent
	
}
