@FunctionalInterface
public interface GLViewPerFrameLog {
	String getLog();
}
