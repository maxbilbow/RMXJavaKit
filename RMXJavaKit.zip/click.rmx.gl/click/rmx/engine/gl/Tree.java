public class Tree<T>
{
  T data;
  T child;
}
