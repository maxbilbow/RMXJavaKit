import java.util.HashMap;

public final class KeyStates extends HashMap<Integer,Boolean> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}