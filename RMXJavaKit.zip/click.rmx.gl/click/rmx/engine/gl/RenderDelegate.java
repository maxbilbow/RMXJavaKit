public interface RenderDelegate {
	public void updateBeforeSceneLogic(Object... args);
	public void updateBeforeSceneRender(Object... args);
//	public void updateLast(Object args);
}
