public interface Glu {
	public void display();
	public void mousePassive(int x, int y);
	public void keyDown(int key);
	public void keyUp(int key);
	public void AnimateScene();
	public void reshape (int width, int height);
	public void debug();
	
}
